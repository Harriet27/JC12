import React from 'react'
class Home extends React.Component{
    render(){
        return(
            <div>
                <h1>Remedial Front End</h1>
            </div>
        )
    }
}

export default Home