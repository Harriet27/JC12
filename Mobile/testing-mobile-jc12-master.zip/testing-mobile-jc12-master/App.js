import React from 'react';

import Todo from './Screens/Todo';
import Sandbox from './Screens/Sandbox';
import Latihan from './Screens/Latihan';

const App = () => {
  return <Latihan />;
};

export default App;
