export const ZOMATO_URL = 'https://developers.zomato.com/api/v2.1/';
export const ZOMATO_KEY = 'd3b71f27721be564f7a98cc5d01bd9d4';
export const primary_colour = '#CB202D';
