import React from 'react';

const NotFound = () => {
    return ( 
        <div>
            <h4 style={{ color: '#009C95' }}>Page Not Found</h4>
        </div>
    );
};

export default NotFound;