import HeaderDashboard from './HeaderDasboard';
import SiderDashboard from './SiderDashboard';

export {
    HeaderDashboard,
    SiderDashboard
}