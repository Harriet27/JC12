export const setModal = () => {
    return{
        type : 'MODAL_SHOW'
    }
}